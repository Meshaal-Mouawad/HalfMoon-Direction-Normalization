HALF-MOON V13 - PATTERN RECOGNITION LETTERS
Existing Editorial Manager record: PRLETTERS-D-26-03032
Article: Global loss bounds and one-bit recovery for direction-normalized half-moons
Author: Meshaal Mouawad
Baseline commit: d3ddee51c783387475d48cdead83ad20a3c89df2

EXTRACT THE ZIP BEFORE JOURNAL UPLOAD.
Upload the seven files under Journal_Upload/ as separate items as appropriate.
This ZIP is a local delivery container, not itself a manuscript file.

PENDING AUTHOR ACTION: The separately signed Confirmation of Authorship
is not included because it is absent from the verified GitHub folder.
Upload the signed form to the existing Editorial Manager record,
check the assembled journal PDF, and approve the final submission.
This archive does not indicate that a resubmission was performed.
