Half-Moon V14 PRL journal upload (existing manuscript PRLETTERS-D-26-03032)
Author: Meshaal Mouawad
Only editorial corrections E1, E2, P1 were applied to the main article.
Seven-page revised Manuscript.pdf; 18-page Supplement.pdf; 3-page Threshold_Addendum.pdf.
The ZIP is a transfer container; extract and upload its Journal_Upload files individually.
The signed Confirmation of Authorship is absent from this archive and must be uploaded separately.
No Editorial Manager portal operation or resubmission has been performed.
