Half-Moon PRL V16 journal-upload delivery package
Title: Global loss bounds and one-bit recovery for direction-normalized half-moons
Existing journal record: PRLETTERS-D-26-03032
Corrected one remaining V15 float interruption (R1-B), no scientific edits.
Extract this ZIP and upload individual Journal_Upload/ files to Editorial Manager.
Signed Confirmation of Authorship is a separate required author file, not included.
No journal submission has been performed from this build.
