HalfMoon PRL V15 — Editorial Manager submission handoff
Existing record PRLETTERS-D-26-03032
R1 float/page-flow repair only; previous approved scientific claims preserved.
Extract the archive and upload individual Journal_Upload/ files.
Signed Confirmation of Authorship is a separate required author form and is not included.
No journal submission has been performed.
