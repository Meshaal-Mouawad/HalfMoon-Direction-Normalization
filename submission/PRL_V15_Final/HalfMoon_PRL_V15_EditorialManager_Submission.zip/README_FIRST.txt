HALF-MOON V15 — Pattern Recognition Letters
Article: Global loss bounds and one-bit recovery for direction-normalized half-moons
Existing Editorial Manager record PRLETTERS-D-26-03032
Source baseline: V14 at GitHub commit b5aa9986fcbf560f45a2d7d69e32bd8eafba51b3
Correction: R1 two float-interrupted Methods sentences, plus optional nonbreakable convex-hull word pair.
Extract this delivery ZIP. Upload Journal_Upload/ contents as individual portal items.
Signed Confirmation of Authorship must be uploaded separately.
No journal portal action has been performed.
