Supplementary material
Exact radial coding limits for direction-normalized half-moons
Meshaal Mouawad

Supplement.tex is the editable source. The four PDF files are vector figures.
Supplement_References.bib contains the cited works. The unmodified Elsevier
article class and its numbered BibTeX style are included, together with the
generated Supplement.bbl.

Build with a standard TeX Live or MiKTeX installation in this directory:

  pdflatex Supplement.tex
  bibtex Supplement
  pdflatex Supplement.tex
  pdflatex Supplement.tex

The output is Supplement.pdf. The numerical and training data are described
in the supplement and provided separately from its typesetting files.
