"""Illustrate the proved asymptotic from the original greedy map using decimal arithmetic."""
from decimal import Decimal as D, localcontext
import csv
from pathlib import Path


def radius_count(v_string, exponent=None, h_input=None, extra=0):
    digits=3*(exponent or 10)+90+extra
    with localcontext() as ctx:
        ctx.prec=digits
        d=D('.5')
        v=D(v_string)
        w=d*v
        a,b=2*d-w,2*d+w
        h0=2*d*(1-v).sqrt()
        if h_input is None:
            delta=D(10)**(-exponent)
            h=h0*(1-delta)
        else:
            h=D(h_input)
            delta=1-h/h0
        k=h/2
        target=((b-d)**2+k*k).sqrt()
        t=((a-d)**2+k*k).sqrt()
        count=1
        while t<target:
            q=(d*(t*t-k*k).sqrt()-k*k)/t
            new_t=q+(q*q+a*a-d*d-k*k).sqrt()
            assert new_t>t
            t=new_t
            count+=1
        left=1/(1-v)
        right=(1-v)*(2+v)/((1+v)*(2-v+v*v))
        constant=1/left.ln()+1/(1/right).ln()
        leading=constant*(1/delta).ln()
        return count,float(delta),float(constant),float(leading),float(count-leading)


if __name__=='__main__':
    rows=[]
    for v in ['.20','.40','.50','.80']:
        for n in [2,4,8,12,20,40,80,100]:
            N,delta,K,lead,residual=radius_count(v,n)
            checked=radius_count(v,n,extra=50)
            assert checked[0]==N
            rows.append([v,n,delta,N,K,lead,residual])
    p=Path(__file__).with_name('rate_checks.csv')
    with p.open('w',newline='') as f:
        w=csv.writer(f)
        w.writerow(['width_ratio','minus_log10_relative_gap','relative_gap','minimum_symbols','log_coefficient','leading_log_term','observed_minus_leading'])
        w.writerows(rows)
    print(*[r for r in rows if r[0]=='.40'],sep='\n')
    print('original h=0.7745966:',radius_count('.40',h_input='0.7745966'))
