Width dependence near contact
Supplementary Table S7 of Exact radial coding limits for direction-normalized half-moons

To reproduce the four rows, extract the archive and run these commands from
the extracted directory with Python 3.8 or later. Only the standard library
is required.

  python3 certify_width.py > reproduced.csv
  python3 -c "from pathlib import Path as P; assert P('reproduced.csv').read_text() == P('width_certificates.csv').read_text()"

The four widths use d=1/2, v=w/d, a=2d-w, b=2d+w and h=(1-epsilon)h_c
with h_c=2d sqrt(1-v) and epsilon=10^-8. For each width the script sets
k=h/2, z_b=sqrt((b-d)^2+k^2), and t_0=sqrt((a-d)^2+k^2). For t_i<z_b it
evaluates the recurrence in Theorem 3,

  p = [d sqrt(t_i^2 - k^2) - k^2] / t_i
  t_(i+1) = p + sqrt(p^2 + a^2 - d^2 - k^2).

The first index m at which t_m reaches z_b gives M=m+1. The routine tests
every iterate against z_b and verifies that every step advances. The output
columns previous_gap and crossing_gap enclose z_b-t_(m-1) and t_m-z_b,
respectively. Both lower endpoints are strictly positive in every row.

The interval endpoints are integers in units of 10^-200. Exact integer
operations give lower and upper endpoints by floor and ceiling. For sqrt
the integer square root gives the floor and its square determines whether
the upper endpoint needs one extra unit. This encloses h_c, h, z_b, t_0 and
every map evaluation. Reported endpoints are rounded outward to 18 decimal
places. The displayed coefficient uses the analytical formula in Corollary 4,
evaluated separately with 80-digit decimal arithmetic and rounded to six
decimal places. The coefficient does not enter any stopping test.

rate/rate_checks.csv and rate/check_rate.py are the original calculations
for eight relative gaps per width. Running python3 rate/check_rate.py
regenerates rate/rate_checks.csv. The certification script independently
recomputes and checks the four Table S7 counts and rounded coefficients
against the matching rows in that archive.
