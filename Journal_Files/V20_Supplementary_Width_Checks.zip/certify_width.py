"""Certify the four stopping indices in supplementary Table S7 (Python 3.8+)."""
import csv
import sys
from dataclasses import dataclass
from decimal import Decimal, localcontext
from math import isqrt
from pathlib import Path

# All intervals are closed. Endpoints are exact integers divided by SCALE.
PLACES = 200
SCALE = 10**PLACES


def ceil_div(a, b):
    return -((-a) // b)


@dataclass(frozen=True)
class Interval:
    lo: int
    hi: int

    @classmethod
    def rational(cls, numerator, denominator=1):
        n = numerator * SCALE
        return cls(n // denominator, ceil_div(n, denominator))

    def __add__(self, other):
        return Interval(self.lo + other.lo, self.hi + other.hi)

    def __sub__(self, other):
        return Interval(self.lo - other.hi, self.hi - other.lo)

    def __mul__(self, other):
        products = [x * y for x in (self.lo, self.hi) for y in (other.lo, other.hi)]
        return Interval(min(products) // SCALE, ceil_div(max(products), SCALE))

    def __truediv__(self, other):
        if other.lo <= 0:
            raise ValueError("This calculation requires a positive denominator.")
        corners = [(x * SCALE, y) for x in (self.lo, self.hi)
                   for y in (other.lo, other.hi)]
        return Interval(min(n // d for n, d in corners), max(ceil_div(n, d) for n, d in corners))

    def square(self):
        low = 0 if self.lo <= 0 <= self.hi else min(self.lo**2, self.hi**2)
        return Interval(low // SCALE, ceil_div(max(self.lo**2, self.hi**2), SCALE))

    def sqrt(self):
        if self.lo < 0:
            raise ValueError("Square root requires a nonnegative lower endpoint.")
        lo = isqrt(self.lo * SCALE)
        top = self.hi * SCALE
        hi = isqrt(top)
        return Interval(lo, hi if hi**2 == top else hi + 1)


def format_bound(x, upper=False, places=18):
    factor = 10**(PLACES - places)
    n = ceil_div(x, factor) if upper else x // factor
    sign = "-" if n < 0 else ""
    whole, decimals = divmod(abs(n), 10**places)
    return f"{sign}{whole}.{decimals:0{places}d}"


def stopping_test(width_percent):
    one, two, d = Interval.rational(1), Interval.rational(2), Interval.rational(1, 2)
    v, epsilon = Interval.rational(width_percent, 100), Interval.rational(1, 10**8)
    a, b = two * d - d * v, two * d + d * v
    contact = two * d * (one - v).sqrt()
    h = contact * (one - epsilon)
    k2 = (h / two).square()
    target = ((b - d).square() + k2).sqrt()
    t = ((a - d).square() + k2).sqrt()
    m = 0
    previous_gap = None
    while True:
        gap = target - t
        if gap.hi <= 0:
            if previous_gap is None or gap.hi == 0:
                raise ArithmeticError("A strict final crossing was expected.")
            return m, h, previous_gap, t - target
        if gap.lo <= 0:
            raise ArithmeticError("Stopping test unresolved at this precision.")
        previous_gap = gap
        p = (d * (t.square() - k2).sqrt() - k2) / t
        next_t = p + (p.square() + a.square() - d.square() - k2).sqrt()
        if next_t.lo <= t.hi:
            raise ArithmeticError("Could not separate successive cutoffs.")
        t = next_t
        m += 1


def log_coefficient(width_percent):
    with localcontext() as ctx:
        ctx.prec = 80
        v = Decimal(width_percent) / 100
        left = 1 / (1 - v)
        right = (1 - v) * (2 + v) / ((1 + v) * (2 - v + v*v))
        return 1 / left.ln() + 1 / (1 / right).ln()


def main():
    archive = Path(__file__).parent / "rate" / "rate_checks.csv"
    with archive.open(newline="") as stream:
        rows = {Decimal(r["width_ratio"]): r for r in csv.DictReader(stream)
                if int(r["minus_log10_relative_gap"]) == 8}
    writer = csv.writer(sys.stdout, lineterminator="\n")
    writer.writerow(["width_ratio", "relative_gap", "C_6dp", "cutoffs_m", "minimum_symbols",
                     "h_lower", "h_upper", "previous_gap_lower", "previous_gap_upper",
                     "crossing_gap_lower", "crossing_gap_upper"])
    for width_percent in (20, 40, 50, 80):
        v = Decimal(width_percent) / 100
        m, h, previous, crossing = stopping_test(width_percent)
        coefficient = format(log_coefficient(width_percent), ".6f")
        archived = rows[v]
        if (m + 1 != int(archived["minimum_symbols"])
                or coefficient != format(Decimal(archived["log_coefficient"]), ".6f")):
            raise ValueError("Certified count or calculated coefficient differs from source table.")
        bounds = [bound for interval in (h, previous, crossing)
                  for bound in (format_bound(interval.lo), format_bound(interval.hi, upper=True))]
        writer.writerow([format(v, ".2f"), "1e-8", coefficient, m, m + 1, *bounds])


if __name__ == "__main__":
    main()
