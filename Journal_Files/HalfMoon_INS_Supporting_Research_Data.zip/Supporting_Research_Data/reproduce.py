"""Recompute the numerical results into a separate folder and compare the reference data."""
from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
CODE = ROOT / "code"
REFERENCE = ROOT / "results"


def run(script, *args, stdout=None):
    command = [sys.executable, str(CODE / script), *(str(x) for x in args)]
    if stdout:
        with stdout.open("w", encoding="utf-8") as stream:
            subprocess.run(command, check=True, stdout=stream)
    else:
        subprocess.run(command, check=True)


def compare(reference, generated):
    def rows(path):
        if path.suffix == ".csv":
            with path.open(encoding="utf-8", newline="") as f:
                return list(csv.reader(f))
        return [line.split() for line in path.read_text(encoding="utf-8").splitlines()]

    expected, observed = rows(reference), rows(generated)
    if len(expected) != len(observed):
        raise ValueError(f"{reference.name}: row counts differ")
    for i, (original, recreated) in enumerate(zip(expected, observed), 1):
        if len(original) != len(recreated):
            raise ValueError(f"{reference.name}: column counts differ in row {i}")
        for j, (a, b) in enumerate(zip(original, recreated), 1):
            if a == b:
                continue
            try:
                # Numerical cutoff searches may differ in their final decimal places.
                allowed = 5e-7 if (reference.name=="population_risks.csv" and j==4) else 1e-10
                if math.isclose(float(a), float(b), rel_tol=1e-10, abs_tol=allowed):
                    continue
            except ValueError:
                pass
            raise ValueError(f"{reference.name}, row {i}, column {j}: {a} vs {b}")


def check_frozen_counts():
    with (REFERENCE/"frozen_one_bit_test_counts.csv").open(encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))
    names = ["test_examples", "raw_errors", "direction_errors", "direction_bit_errors",
             "direction_radius_errors", "explicit_decoder_errors"]
    counts = [sum(int(row[key]) for row in rows) for key in names]
    assert [int(row["seed"]) for row in rows] == list(range(2001,2011))
    assert counts == [500000,0,54362,3,0,0]
    print("Frozen test counts verified across ten seeds:", counts, flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=ROOT/"reproduced")
    out = parser.parse_args().out.resolve()
    if out == ROOT or REFERENCE in [out, *out.parents] or (ROOT/"figures") in [out,*out.parents]:
        raise ValueError("Choose a separate output folder to preserve the reference results.")
    data, figures = out/"results", out/"figures"
    data.mkdir(parents=True, exist_ok=True)
    figures.mkdir(parents=True, exist_ok=True)
    run("verify_alphabet.py", data/"alphabet_sizes.csv")
    run("check_alphabets.py", data/"alphabet_sizes.csv", stdout=data/"independent_alphabet_check.txt")
    run("verify_strip_risk.py", stdout=data/"strip_risks.tsv")
    run("check_nominal_risks.py", stdout=data/"nominal_risks.txt")
    for script in ["width_study.py","threshold_study.py"]:
        run(script,"--out",data)
    for stem in ["width_phase","threshold_phase"]:
        for suffix in [".pdf",".png"]:
            shutil.move(data/(stem+suffix),figures/(stem+suffix))
    run("plot_contact_codes.py",figures/"contact_codes.pdf")
    for name in ["alphabet_sizes.csv","independent_alphabet_check.txt","strip_risks.tsv",
                 "nominal_risks.txt","population_risks.csv","risk_curves.csv","width_checks.csv"]:
        compare(REFERENCE/name, data/name)
        print("Verified",name,flush=True)
    check_frozen_counts()
    print("All checks passed. Recreated PDFs and tables:",out)


if __name__=="__main__":
    main()
