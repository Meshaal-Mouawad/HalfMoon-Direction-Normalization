# Supporting research data for classification of direction-normalized half-moons

This archive contains the results, Python programs, and vector figures for the radial-code analysis of two half-annular class supports. It also includes the ten archived one-bit neural test counts used in the article. The analytical experiments operate on the specified continuous populations and require no downloaded data or model weights.

## Reproduce

Unzip the file and enter the `Supporting_Research_Data` directory. The tested runtime was CPython 3.12.14. Install the four pinned scientific libraries in a Python 3.12 environment, then run the single entry point.

```sh
python -m pip install -r requirements.txt
python reproduce.py
```

The run creates `reproduced/results/` and `reproduced/figures/`. It checks seven recomputed result files against their supplied references and verifies the frozen test counts. Select a different destination with `python reproduce.py --out /path/to/output`. The supplied reference results and figures stay in their respective directories. The two angular-grid checks use arrays of 1,048,576 directions.

## Contents and units

| Reference file in `results/` | Meaning |
|---|---|
| `alphabet_sizes.csv` | Minimum radial alphabet sizes at 14 exact decimal displacements. The three reported distances use the native coordinate units. The count computation uses 65-decimal outward-rounded arithmetic. |
| `independent_alphabet_check.txt` | Independent circle-intersection computation of the same counts at 85-decimal precision, with three scale-invariance checks. |
| `population_risks.csv` | Risks for ten displacements at the benchmark width, with geometric lower and upper cutoff constraints, the selected cutoff, and numerical cross-check discrepancies. Risks are probabilities. Multiply by 100 for percentages. The cutoff is the center of the exact interval when feasible and comes from a grid scan and local refinement above the one-bit transition. |
| `risk_curves.csv` | Bayes-risk profiles vs the common radius threshold at three displacements. The full-circle quadrature uses 131,072 angles. |
| `width_checks.csv` | Twelve geometric checks across four relative widths and three displacements per width. Horizontal separation is one in these units. The geometric bounds come from the theorem. The mesh bounds come from direct full-circle support intersections. |
| `strip_risks.tsv` | Integrated total mass and Bayes error for the rectangular-strip example, with closed-form values and absolute discrepancies at six finite viewing distances. |
| `nominal_risks.txt` | Recomputed direction-only population risks for the nine displacement and origin pairs in the earlier benchmark. |
| `frozen_one_bit_test_counts.csv` | Misclassifications per input on the same 50,000 balanced test observations per seed. The observations are shared across representations. Counts are transcribed from the archived supplement for seeds 2001–2010. |

The `figures/` directory contains the article’s numerical phase, risk-profile, and contact plots in vector PDF. Their Python sources in `code/` calculate the plotted geometry, curves, or class-membership witnesses directly. The reproduced PDFs can differ in metadata such as creation time.

## Earlier neural experiment

The one-bit neural test rows total 500,000 observations. Raw coordinates, midpoint direction alone, direction plus a binary radius measurement, and direction plus full radius gave 0, 54,362, 3, and 0 errors, respectively. The explicit geometric decoder gave zero errors. `reproduce.py` checks these transcribed counts. The new scripts reproduce the population and geometric analyses. The original training, initialization, selection, and prediction assets are identified in the earlier release cited in the manuscript.

[Earlier HalfMoon research release](https://github.com/Meshaal-Mouawad/HalfMoon-Direction-Normalization/releases/tag/v11-submission)
