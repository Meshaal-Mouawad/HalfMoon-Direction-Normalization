"""Independently evaluate equal-prior, area-uniform Bayes risks from ray intervals."""
from math import cos, sin, pi, sqrt
from scipy.integrate import quad
a, b = 0.8, 1.2
H = pi*(b*b-a*a)/2
def rayclass(origin, center, upper, theta):
    vx, vy = (x-y for x,y in zip(origin, center))
    ux, uy = cos(theta), sin(theta)
    prod = vx*ux+vy*uy
    j = vx*uy-vy*ux
    if abs(j)>=b:
        return 0.
    def roots(rad):
        extent=sqrt(max(0,rad*rad-j*j))
        return (-prod-extent, -prod+extent)
    l, r = roots(b)
    ii, jj = roots(a) if abs(j)<a else (l,l)
    total=0.
    for lo, hi in ((l,ii),(jj,r)):
        lo=max(0,lo)
        if uy*upper>0:
            lo=max(lo,-vy/uy)
        elif uy*upper<0:
            hi=min(hi,-vy/uy)
        elif upper*vy<=0:
            continue
        if hi>lo:
            total+=(hi*hi-lo*lo)/(2*H)
    return total
def risk(h, origin):
    def area(theta):
        return min(rayclass(origin,(0,0),1,theta),rayclass(origin,(1,h),-1,theta))/2
    # Dense angular subdivision stabilizes adaptive integration at support endpoints.
    cells=512
    return sum(quad(area,2*pi*i/cells,2*pi*(i+1)/cells,epsabs=1e-12,epsrel=1e-10,limit=500)[0] for i in range(cells))
if __name__=='__main__':
    for h in (-.25,.5,1):
        for label,o in [('zero',(0,0)),('mid',(.5,h/2)),('upper',(0,3))]:
            print(h,label,format(risk(h,o),'.11f'))
