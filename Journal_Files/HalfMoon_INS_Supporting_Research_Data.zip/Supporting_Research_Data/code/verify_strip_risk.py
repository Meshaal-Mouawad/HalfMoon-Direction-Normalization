"""Independently integrate class-specific ray masses on the strip example."""
from math import hypot
from scipy.integrate import quad

def angular_masses(t, R):
    # At fixed t=|x|/(R-y), support ends at |x|=2.
    if t == 0:
        return R / 2, 0.
    lo = max(-1., R - 2./t)
    if lo >= 1.:
        return 0., 0.
    split = min(1., max(lo, R - 1./t))
    def mass(a, b):
        # Probability Jacobian includes both signs of x.
        return (b-a)*(R-(a+b)/2.)/4.
    return mass(split, 1.), mass(lo, split)

def integrate_risk(R):
    end = 2./(R-1.)
    # Points below are support/label geometry transitions, not the analytic Bayes tie.
    edges = [1./(R+1.), 1./(R-1.), 2./(R+1.)]
    kw = dict(points=sorted(set(edges)), epsabs=1.e-13, epsrel=2.e-13, limit=500)
    prob = quad(lambda t: sum(angular_masses(t, R)), 0., end, **kw)[0]
    risk = quad(lambda t: min(angular_masses(t, R)), 0., end, **kw)[0]
    target = 1./(2*(hypot(R, 1.)+R))
    print(f'{R:.1f}\t{prob:.13f}\t{risk:.13f}\t{target:.13f}\t{abs(risk-target):.3g}')
    assert abs(prob-1.) < 2.e-12 and abs(risk-target) < 2.e-12

if __name__ == '__main__':
    print('R\ttotal_mass\tquadrature\tclosed_form\tabsolute_difference')
    for R in (3., 3.5, 4., 5., 10., 20.): integrate_risk(R)
