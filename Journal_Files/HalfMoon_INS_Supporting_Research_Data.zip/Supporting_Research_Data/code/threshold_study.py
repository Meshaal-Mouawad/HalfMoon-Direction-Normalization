"""Recreate phase curves, population risks, and a numerical cross-check.

Run python threshold_study.py --out results
Requires Python 3.10+, numpy, scipy, matplotlib. The outputs are deterministic.
Inputs are the analytic half-annuli, and no fitted classifiers or test sets are used.
"""
from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.integrate import quad
from scipy.optimize import minimize_scalar

A, B = 0.8, 1.2
CLASS_AREA = math.pi * (B**2 - A**2) / 2
CRITICAL = math.sqrt(27 / 85)
TOUCH = math.sqrt(3 / 5)


def threshold_bounds(h):
    d2 = (h / 2) ** 2
    return np.sqrt(0.49 + d2), (0.39 - d2) / np.sqrt(0.09 + d2)


def intervals(h, theta):
    """Ray intersections with the open supports; the midpoint lies in both holes."""
    d = h / 2
    x, y = np.cos(theta), np.sin(theta)
    proj = 0.5 * x + d * y
    offset = 0.25 + d**2
    inner = np.sqrt(proj**2 + A**2 - offset)
    outer = np.sqrt(proj**2 + B**2 - offset)
    with np.errstate(divide="ignore"):
        cap0 = np.where(y < 0, -d / y, np.inf)
        cap1 = np.where(y > 0, d / y, np.inf)
    return (inner - proj, np.minimum(outer - proj, cap0),
            inner + proj, np.minimum(outer + proj, cap1))


def band_mass(lo, hi):
    return 0.5 * np.maximum(hi**2 - lo**2, 0)


def ambiguous_mass(interval, t):
    lo0, hi0, lo1, hi1 = interval
    n0 = band_mass(lo0, np.minimum(t, hi0))
    n1 = band_mass(lo1, np.minimum(t, hi1))
    f0 = band_mass(np.maximum(t, lo0), hi0)
    f1 = band_mass(np.maximum(t, lo1), hi1)
    return np.minimum(n0, n1) + np.minimum(f0, f1)


def adaptive(h, t):
    """Integrate over one of the two antipodal collision arcs; double by symmetry."""
    d = h / 2
    left, right = -math.atan2(d, A - 0.5), math.atan2(d, A + 0.5)
    events = [left, right, 0.0, -math.atan2(d, B - 0.5), math.atan2(d, B + 0.5)]
    if 0 < t < math.inf:
        # Intersections of the threshold circle with both class-boundary circles
        # and with the two horizontal support boundaries.
        cnorm = math.hypot(0.5, d)
        direction = math.atan2(d, 0.5)
        for radius in (A, B):
            q = (radius**2 - cnorm**2 - t**2) / (2 * t * cnorm)
            if abs(q) <= 1:
                for v in (q, -q):
                    angle = math.acos(v)
                    events.extend([direction - angle, direction + angle])
        if t >= d:
            cap = math.asin(d / t)
            events.extend([-cap, cap])
    # Additional uniform breakpoints aid the adaptive integrator at crossings of
    # the two per-bin area contributions (where the Bayes label changes).
    events.extend(np.linspace(left, right, 17))
    bounds = sorted(set(a for a in events if left <= a <= right))

    def density(theta):
        return ambiguous_mass(intervals(h, theta), t) / CLASS_AREA

    value = 0.0
    for a, b in zip(bounds[:-1], bounds[1:]):
        if b - a < 1e-14:
            continue
        integral, _ = quad(density, a, b, epsabs=2e-12, epsrel=1e-10, limit=100)
        value += integral
    return value


def polygonal_grid(h, n=32768):
    """Independent full-circle midpoint rule: both classes and all angles retained."""
    theta = (np.arange(n) + 0.5) * (2 * np.pi / n)
    interval = intervals(h, theta)

    def risk(t):
        mass = ambiguous_mass(interval, t)
        return np.mean(mass) * np.pi / CLASS_AREA

    return risk


def empirical_bounds(h, n=1048576):
    """Check the two constraints directly on the full circle, without an arc formula."""
    theta = (np.arange(n) + 0.5) * (2 * np.pi / n)
    lo0, hi0, lo1, hi1 = intervals(h, theta)
    active = (lo0 < hi0) & (lo1 < hi1)
    first0 = lo0 < lo1
    near_upper = np.where(first0, hi0, hi1)
    far_lower = np.where(first0, lo1, lo0)
    return np.max(near_upper[active]), np.min(far_lower[active])


def numerical_cutoff(h):
    """Scan the complete relevant range, then refine every interior grid minimum."""
    lower, upper = threshold_bounds(h)
    if h <= CRITICAL:
        return float((lower + upper) / 2)
    grid_risk = polygonal_grid(h, 8192)
    # Between U and L there is the possible tradeoff. Outside this range,
    # moving toward it weakly decreases collision mass on every direction.
    grid = np.linspace(upper, lower, 257)
    losses = np.array([grid_risk(t) for t in grid])
    candidate_ids = np.where((losses[1:-1] <= losses[:-2]) &
                             (losses[1:-1] <= losses[2:]))[0] + 1
    candidates = [(adaptive(h, t), t) for t in [grid[0], grid[-1]]]
    for idx in candidate_ids:
        # The bracketing window spans adjacent grid points with an extra node
        # either side to absorb the angular-mesh error in the initial scan.
        a, b = grid[max(0, idx-2)], grid[min(len(grid)-1, idx+2)]
        result = minimize_scalar(lambda t: adaptive(h, t), bounds=(a, b),
                                 method="bounded", options={"xatol": 1e-8})
        candidates.append((result.fun, result.x))
    return min(candidates)[1]


def write_table(path, fieldnames, rows):
    with path.open("w", newline="") as stream:
        w = csv.DictWriter(stream, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)


def draw_figure(out, curves):
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9,
                         "pdf.fonttype": 42, "svg.fonttype": "none",
                         "axes.spines.top": False, "axes.spines.right": False,
                         "axes.labelcolor":"#233749", "text.color":"#233749",
                         "axes.edgecolor":"#657788", "xtick.color":"#425768",
                         "ytick.color":"#425768", "lines.solid_capstyle":"round"})
    fig, axs = plt.subplots(1, 2, figsize=(8.1, 3.05), constrained_layout=True)
    ax = axs[0]
    h = np.linspace(1e-5, TOUCH, 1001)
    lo, hi = threshold_bounds(h)
    ax.fill_between(h, lo, hi, where=h < CRITICAL, color="#d5e9e4")
    ax.plot(h, hi, color="#1e7065", label="Upper bound", lw=1.65)
    ax.plot(h, lo, color="#264966", label="Lower bound", lw=1.65)
    ax.axvline(CRITICAL, color="#687c87", linestyle=(0,(3,3)), lw=.8)
    ax.plot(CRITICAL, threshold_bounds(CRITICAL)[0], "o", ms=4, color="#273c4f")
    ax.annotate(r"$h_{\star}=0.5636$", (CRITICAL,.51), xytext=(-4,1),
                textcoords="offset points", ha="right", fontsize=8)
    ax.text(.18,.92,"Exact recovery", fontsize=8.7, color="#245b51", ha="center")
    ax.set(xlim=(0,.79), ylim=(.46,1.32), xlabel="Center displacement $h$",
           ylabel="Common radius threshold $t$")
    ax.set_title("A   Exact recovery at the midpoint", loc="left", fontweight="semibold", fontsize=10)
    ax.legend(frameon=False, fontsize=7.5, loc="upper right")
    ax = axs[1]
    for h, values in curves.items():
        ts, risk = np.array(values).T
        ax.plot(ts, risk*100, label=f"$h={h:.2f}$",
                color={.5:"#21689a",.65:"#237267",.75:"#b95414"}[h], lw=1.65)
    ax.set(xlim=(.55,.94), ylim=(-.11,None), xlabel="Common radius threshold $t$",
           ylabel="Population Bayes error (%)")
    ax.set_title("B   Error with unrestricted decoding", loc="left", fontweight="semibold", fontsize=10)
    ax.legend(frameon=False, fontsize=7.5)
    for ax in axs:
        ax.set_axisbelow(True)
        ax.grid(axis="y", lw=.45, color="#e0e6eb")
    for ext in ("pdf","png"):
        fig.savefig(out / f"threshold_phase.{ext}", dpi=250)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path("results"))
    out = parser.parse_args().out
    out.mkdir(exist_ok=True, parents=True)
    rows = []
    for h in [.10, .25, .5, CRITICAL, .575, .6, .65, .70, .75, TOUCH]:
        lo, hi = threshold_bounds(h)
        t = numerical_cutoff(h)
        selected = adaptive(h, t)
        validation = polygonal_grid(h, 1048576)
        direction = adaptive(h, math.inf)
        fixed = adaptive(h, .8)
        errors = [abs(a - validation(x)) for x,a in
                  [(t, selected), (math.inf, direction), (.8, fixed)]]
        assert max(errors) < 5e-8, (h, errors)
        mesh_lower, mesh_upper = empirical_bounds(h)
        endpoint_discrepancy = max(abs(lo-mesh_lower), abs(hi-mesh_upper))
        assert endpoint_discrepancy < 2e-5, (h, endpoint_discrepancy)
        rows.append(dict(h=h, lower_constraint=lo, upper_constraint=hi,
                         selected_threshold=t, bit_risk=selected,
                         direction_risk=direction, threshold_0_8_risk=fixed,
                         max_abs_full_circle_difference=max(errors),
                         max_abs_endpoint_mesh_difference=endpoint_discrepancy))
        print(h, t, selected, direction, max(errors), flush=True)
    write_table(out / "population_risks.csv", rows[0].keys(), rows)
    curves = {}
    curve_rows = []
    for h in [.5, .65, .75]:
        evaluate = polygonal_grid(h, 131072)
        ts = np.unique(np.r_[np.linspace(.55, .94, 251), threshold_bounds(h)])
        values = [(float(t), float(evaluate(t))) for t in ts if .55 <= t <= .94]
        curves[h] = values
        curve_rows.extend(dict(h=h,t=t,bit_risk=risk) for t,risk in values)
    write_table(out / "risk_curves.csv", ["h", "t", "bit_risk"], curve_rows)
    draw_figure(out, curves)


if __name__ == "__main__":
    main()
