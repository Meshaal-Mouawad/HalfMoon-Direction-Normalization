"""Enclose and verify the optimal scalar alphabet size at representative displacements.

Usage: python verify_alphabet.py [output.csv]
Use rational decimal inputs and outward-rounded interval arithmetic. An unresolved
threshold comparison raises an error instead of choosing a side by tolerance.
"""
import csv
from pathlib import Path
import sys

from mpmath import iv

iv.dps = 65
EXPECTED = {'0.25':2, '0.50':2, '0.57':3, '0.60':3, '0.65':3, '0.70':4, '0.73':5,
            '0.75':7, '0.76':8, '0.77':13, '0.774':21, '0.7745':28, '0.77459':39,
            '0.7745966':56}


def minimum_code(h):
    a, b, d, k = iv.mpf('0.8'), iv.mpf('1.2'), iv.mpf('0.5'), iv.mpf(h)/2
    lower = iv.sqrt((a-d)**2+k*k)
    upper = iv.sqrt((b-d)**2+k*k)
    previous = lower
    for symbols in range(2,501):
        q = (d*iv.sqrt(previous**2-k*k)-k*k)/previous
        current = q + iv.sqrt(q*q + a*a-d*d-k*k)
        if current.a > upper.b:
            return symbols, previous, current, upper
        if not current.b < upper.a:
            raise ArithmeticError(f'Unresolved boundary comparison at h={h}, symbols={symbols}')
        previous = current
    raise ArithmeticError('Increase iteration limit or prove nontermination analytically')


if __name__ == '__main__':
    output = Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name('alphabet_sizes.csv')
    with output.open('w', newline='') as stream:
        writer = csv.writer(stream)
        writer.writerow(['h','minimum_symbols','previous_cutoff_approx','last_cutoff_approx','maximum_near_exit_approx'])
        for h,expected in EXPECTED.items():
            size,previous,last,upper = minimum_code(h)
            assert size == expected
            writer.writerow([h,size,*(f'{float(x.mid):.12f}' for x in (previous,last,upper))])
    print(f'Verified {len(EXPECTED)} alphabet sizes using strict interval comparisons.')
