"""Compute greedy cutoffs by intersecting each diameter-endpoint ray with the other inner circle."""
import csv
from decimal import Decimal as D, localcontext
from pathlib import Path
import sys

def count(distance, thickness, height):
    d, w, h = map(D, (distance, thickness, height))
    k = h / 2
    a, b = 2*d - w, 2*d + w
    z = ((a-d)**2 + k*k).sqrt()
    last = ((b-d)**2 + k*k).sqrt()
    thresholds = 0
    while z < last:
        # At r=z the ray is at (x,0); advance along it by 'step'
        # to the first exit from the inner disk of the opposite class.
        horizontal = (z*z - k*k).sqrt()
        x = d + horizontal
        unit_x, unit_y = horizontal/z, -k/z
        residual_x, residual_y = x-2*d, -h
        linear = residual_x * unit_x + residual_y * unit_y
        power = residual_x**2 + residual_y**2 - a**2
        step = (linear*linear - power).sqrt() - linear
        assert step > 0
        z += step
        thresholds += 1
        if thresholds > 1_000_000:
            raise RuntimeError
    return thresholds + 1

if __name__ == '__main__':
    table = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1] / "results" / "alphabet_sizes.csv"
    with localcontext() as ctx, table.open() as f:
        ctx.prec = 85
        for row in csv.DictReader(f):
            n = count('.5', '.2', row['h'])
            assert n == int(row['minimum_symbols'])
            print(row['h'], n)
        # Positive rescaling of all lengths must preserve the optimum.
        for d,w,h in [('4','1.6','6.16'),('5','.3','1'),('2','.85','2.88')]:
            n=count(d,w,h)
            n2=count(str(D(d)/13),str(D(w)/13),str(D(h)/13))
            assert n==n2
            print('Scale check',d,w,h,n)
