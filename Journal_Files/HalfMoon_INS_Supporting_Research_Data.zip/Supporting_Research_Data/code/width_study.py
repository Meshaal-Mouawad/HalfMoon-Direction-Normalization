"""Generate the two-parameter phase figure and verify its thresholds from ray intersections.

Run python width_study.py --out results
d is set to 0.5, giving horizontal center separation 2d = 1.
"""
from __future__ import annotations

import argparse
import csv
from pathlib import Path
import math

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def boundaries(v):
    return np.sqrt(2*(1-v)**3/(2-2*v+v**2)), np.sqrt(1-v)


def profile(out):
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9,
                         "pdf.fonttype": 42, "svg.fonttype": "none",
                         "axes.spines.top": False, "axes.spines.right": False,
                         "axes.edgecolor":"#657788","text.color":"#233749",
                         "axes.labelcolor":"#233749","xtick.color":"#425768",
                         "ytick.color":"#425768"})
    fig, ax = plt.subplots(figsize=(5.3,3.05), constrained_layout=True)
    v = np.linspace(0.00001, 0.99999, 3001)
    critical, contact = boundaries(v)
    ax.fill_between(v, 0, critical, color="#e2efeb")
    ax.fill_between(v, critical, contact, color="#f4e5cc")
    ax.fill_between(v, contact, 1, color="#f0f2f4")
    ax.plot(v, critical, color="#1e7065", lw=1.8)
    ax.plot(v, contact, color="#875e25", lw=1.5)
    for point, label, offset in ((.4, r"Original ($v=0.4$)", (-33,-15)), (.5, r"$v=0.5$", (-9,-12))):
        hcrit, hcontact = boundaries(point)
        ax.plot([point,point],[hcrit,hcontact],color="#778994",lw=.7,linestyle=(0,(2,2)))
        ax.scatter([point,point],[hcrit,hcontact],facecolors="white",edgecolors="#314654",
                   linewidth=.9,s=17,zorder=3)
        ax.annotate(label,(point,hcrit),xytext=offset,textcoords="offset points",
                    fontsize=7.3,ha="center" if point==.4 else "right")
    ax.text(.13,.24,"One binary radial\ncode suffices",color="#21594f",
            ha="left",va="center",fontsize=9)
    ax.text(.73,.365,"Disjoint supports\nNo binary radial code",color="#634722",
            ha="center",va="center",fontsize=7.8)
    ax.text(.75,.79,"Overlapping supports",color="#475b68",ha="center",fontsize=8.5)
    ax.set(xlim=(0,1), ylim=(0,1.01), xlabel=r"Relative radial half-width $v=w/d$",
           ylabel=r"Relative displacement $H=h/(2d)$")
    for ext in ("pdf","png"):
        fig.savefig(out / f"width_phase.{ext}", dpi=250)
    plt.close(fig)


def mesh_bounds(v, h, n=2**20):
    """Compute the envelope directly on a full circle with both class supports."""
    d, k = .5, h/2
    a, b = 1-v*d, 1+v*d
    angles = (np.arange(n)+.5)*(2*math.pi/n)
    vx, vy = np.cos(angles), np.sin(angles)
    proj = d*vx+k*vy
    origin2 = d*d+k*k
    inner = np.sqrt(proj**2+a*a-origin2)
    outer = np.sqrt(proj**2+b*b-origin2)
    with np.errstate(divide="ignore"):
        hi0 = np.minimum(outer-proj, np.where(vy<0, -k/vy, np.inf))
        hi1 = np.minimum(outer+proj, np.where(vy>0, k/vy, np.inf))
    lo0, lo1 = inner-proj, inner+proj
    present = (lo0<hi0) & (lo1<hi1)
    first0 = lo0<lo1
    near = np.where(first0,hi0,hi1)[present]
    far = np.where(first0,lo1,lo0)[present]
    # The analytic phase boundary and its predicted bounds are never inputs.
    return np.max(near), np.min(far)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path("results"))
    out = parser.parse_args().out
    out.mkdir(exist_ok=True, parents=True)
    profile(out)
    rows = []
    for v in [.2,.4,.5,.8]:
        crit, contact = boundaries(v)
        for case, h in [("below",.8*crit), ("critical",crit), ("above",(crit+contact)/2)]:
            d, k, a, b = .5, h/2, 1-v/2, 1+v/2
            exact_lo = np.hypot(b-d,k)
            exact_hi = (a*a-d*d-k*k)/np.hypot(a-d,k)
            mesh_lo, mesh_hi = mesh_bounds(v,h)
            err = max(abs(exact_lo-mesh_lo), abs(exact_hi-mesh_hi))
            assert err < 2e-5
            if case=="critical":
                assert abs(exact_hi-exact_lo) < 1e-12 and abs(mesh_hi-mesh_lo) < 4e-5
            else:
                assert ((mesh_hi>mesh_lo) == (case=="below"))
            rows.append(dict(relative_width=v, case=case, H=h, H_critical=crit,
                             H_contact=contact, exact_lower=exact_lo, exact_upper=exact_hi,
                             full_circle_mesh_lower=mesh_lo, full_circle_mesh_upper=mesh_hi,
                             max_abs_constraint_difference=err))
    with (out/"width_checks.csv").open("w",newline="") as stream:
        w = csv.DictWriter(stream, fieldnames=rows[0].keys())
        w.writeheader()
        w.writerows(rows)
    print(f"{len(rows)} directly checked configurations; maximum constraint discrepancy",
          max(row["max_abs_constraint_difference"] for row in rows))


if __name__ == "__main__":
    main()
