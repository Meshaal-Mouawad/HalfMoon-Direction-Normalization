"""Draw exact radial support sections near the first half-moon contact.

Run: python plot_contact_codes.py [output.pdf]
Dependencies: NumPy, Matplotlib. No random sampling or fitted quantities.
"""
from pathlib import Path
import sys

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

A, B = 0.8, 1.2
P, K = 0.5, np.sqrt(3/20)
BLUE, ORANGE = '#22658A', '#B35C28'
LIGHT_BLUE, LIGHT_ORANGE = '#DBEAF0', '#F3E3D8'
INK, MUTE = '#24313B', '#53636F'


def intervals(x):
    """Rays intersect y=0 at x in (a,b]; return angle and both radial bands."""
    d = np.hypot(x-P, K)
    angle = np.degrees(np.arctan2(-K, x-P))
    q = (P * (x-P) - K*K) / d
    s2 = P*P + K*K
    near_lower = -q + np.sqrt(q*q + A*A - s2)
    near_upper = np.minimum(d, -q + np.sqrt(q*q + B*B - s2))
    far_lower = q + np.sqrt(q*q + A*A - s2)
    far_upper = q + np.sqrt(q*q + B*B - s2)
    return angle, near_lower, near_upper, far_lower, far_upper


def draw(output):
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8.3,'axes.titlesize':9.0,
                         'axes.labelsize':8.4,'xtick.labelsize':7.6,'ytick.labelsize':7.6,
                         'axes.linewidth':0.65,'axes.edgecolor':MUTE,'text.color':INK,
                         'axes.labelcolor':INK,'xtick.color':MUTE,'ytick.color':MUTE,
                         'pdf.fonttype':42,'svg.fonttype':'none'})
    fig, (left,right) = plt.subplots(1,2,figsize=(6.4,2.58),gridspec_kw={'width_ratios':[1,1.05]})
    fig.subplots_adjust(left=.087,right=.972,bottom=.221,top=.817,wspace=.34)
    x = np.linspace(1.08,B,600)
    th,ll,n,f,ff = intervals(x)
    ymin,ymax = .690,.816
    rays = intervals(np.array([1.11,1.16]))
    cuts = [(0.704,0.715),(0.753,0.761),(0.784,0.795)]
    # Pairwise conflicts: the near/far labels on each ray must differ.
    for j,(l,r) in enumerate(cuts):
        for i in range(2):
            if j<=i:
                assert rays[1][i] < l < r < rays[2][i]
            else:
                assert rays[3][i] < l < r < rays[4][i]
    assert abs(n[-1]-.8)<1.e-12 and abs(f[-1]-.8)<1.e-12
    left.fill_between(th, ymin, n, facecolor=LIGHT_BLUE)
    left.fill_between(th, f, ymax, facecolor=LIGHT_ORANGE)
    left.plot(th, n, color=BLUE, lw=1.35)
    left.plot(th, f, color=ORANGE, lw=1.35)
    for i,theta in enumerate(rays[0],1):
        left.axvline(theta,color='#74818A',ls=(0,(2,2)),lw=.7)
        left.text(theta,.693,' '+str(i)+' ',ha='center',va='bottom',color=MUTE,size=7.5,
                  bbox={'boxstyle':'square,pad=0.1','facecolor':'white','edgecolor':'none'})
    left.scatter([th[-1]],[.8],s=19,facecolor=INK,zorder=4,edgecolor='white',linewidth=.5)
    left.annotate('contact',(th[-1],.8),xytext=(-8,2),textcoords='offset points',
                  color=INK,ha='right',va='bottom',size=7.3)
    left.text(-33.48,.792,'class 1',color=ORANGE,ha='left',va='center')
    left.text(-30.2,.716,'class 0',color=BLUE,ha='left',va='center')
    left.set(xlim=(th[0],th[-1]+.12),ylim=(ymin,ymax),xlabel='Direction angle (degrees)',ylabel='Radius',
             xticks=[-33,-32,-31,-30,-29],yticks=[.70,.72,.74,.76,.78,.80])
    left.set_title('(a)  Radial support at contact',loc='left',pad=8)
    low,high=.697,.8
    yrows=[1.34,.61]
    for j,(l,r) in enumerate(cuts,1):
        right.axvspan(l,r,ymin=.15,ymax=.86,facecolor='#EEF0F1',zorder=0)
        right.plot([l,r],[1.95]*2, lw=1.1,color=INK,solid_capstyle='butt')
        right.text((l+r)/2,2.03,rf'$I_{j}$',ha='center',va='bottom')
    for i,y in enumerate(yrows):
        right.plot([low,rays[2][i]],[y,y],color=BLUE,lw=7,solid_capstyle='butt')
        right.plot([rays[3][i],high],[y,y],color=ORANGE,lw=7,solid_capstyle='butt')
    right.set(xlim=(low,high),ylim=(.05,2.30),yticks=yrows,yticklabels=['Ray 1','Ray 2'],
              xticks=[.70,.72,.74,.76,.78,.80],xlabel='Radius')
    right.tick_params(axis='y',length=0,pad=2)
    right.spines['left'].set_visible(False)
    right.set_title('(b)  Three distinguishable intervals',loc='left',pad=8)
    for ax in (left,right):
        ax.spines[['top','right']].set_visible(False)
        ax.tick_params(axis='both',width=.65,length=2.5)
    right.tick_params(axis='y',length=0)
    fig.savefig(output,bbox_inches=None,pad_inches=0,metadata={'Title':'Finite radial codes at support contact'})
    plt.close(fig)


if __name__=='__main__':
    draw(Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name('contact_codes.pdf'))
