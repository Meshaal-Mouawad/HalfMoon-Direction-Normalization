# Feedback encoding checks for the reflected half-moons

The scripts check the construction that lets a direction hint select a radial quantizer. They use the two Cartesian class supports, the midpoint, equal class priors, and uniform area within each band. The package also audits the held-out counts reported for the earlier neural experiment.

## Reproduce

Unzip the archive and enter the `V22_Feedback_Checks` directory. The tested interpreter is CPython 3.12.14. In a Python 3.12 environment, install the pinned libraries and run both scripts.

```sh
python -m pip install -r requirements.txt
python feedback_validation.py
python audit_frozen_counts.py
diff -r outputs reproduced
python Figure4/reproduce_figure4.py --out reproduced_figure
```

The scripts write CSVs to `reproduced/` by default. Use `--output PATH` to change the destination. `diff` checks for identical output on the tested runtime. Small last-digit variation is possible across platforms in the floating-point calculations.

## Before contact

The test uses horizontal center separation 1, relative widths 0.20, 0.40, 0.60 and 0.80, and displacement fractions of contact 0.60, 0.75, 0.90 and 0.97. The four additional benchmark displacements at relative width 0.40 are 0.50, 0.60, 0.75 and 0.77. Each geometry uses two radial alphabet budgets, 2 and 4, and is tested at 16,384 and 65,536 equally spaced full-circle midpoint angles. The recurrence generates the design's cutoffs. For evaluation, the code intersects each ray with each band's two circles and half-plane, obtaining the occupied radial intervals directly from the Cartesian support conditions.

Every recurrence cutoff goes in one of the consecutive menus, each containing at most `m-1` cutoffs. On a ray carrying both classes, the design selects the first menu meeting its gap. The equal-spacing control keeps the number of pooled cuts, their two extreme locations, and the per-menu cutoff counts. Its interior cuts are equally spaced. The control selects a menu at each angle by minimizing the conditional error computed from the support areas. The fixed-menu control reuses the designed menus and selects the single menu with the smallest integrated error. Both controls use Bayes-optimal decisions given their representation.

For each angle and menu, the error contribution is the sum over radial bins of the smaller of the two class masses in that bin. A radial interval `(r1,r2)` contributes `(r2²-r1²)/2` units of area per radian. All integrated error columns are percentages of the equal-prior population. The missed-ray columns are counts on the stated angle grid. Geometric identities in the manuscript establish exact recovery and the optimal alphabet sizes on the continuous population. The numerical control errors apply to the specified menus and the stated sampling law.

| Design at the benchmark displacement 0.77 with four feedback menus and four radial bins | Uncovered two-class rays | Error (%) |
| --- | ---: | ---: |
| Recurrence cutoffs with direction feedback | 0 of 24,966 | 0 |
| Equally spaced pooled cutoffs with optimal menu choice | 882 of 24,966 | 0.0064213 |
| Best fixed menu from the recurrence design | — | 0.8306769 |

The recurrence menus covered every sampled two-class ray in all 40 geometry and radial-alphabet configurations at both resolutions. From 16,384 to 65,536 angles, the largest changes in the integrated control errors over those configurations were 0.00000236 percentage points for equally spaced cutoffs and 0.00000810 percentage points for the best fixed menu.

## At first contact

At relative widths `2/5` and `1/4`, the grid check applies the contact radius first, then the first available positive dyadic threshold in the gap, ordered by increasing denominator. All radii of interest in these two geometries lie in `(0,2]`. The reported largest denominator exponent describes the tested rays. The exact arithmetic check treats the rightward rays through `(a,0)` and `(b,0)` and their reflections separately. The `(a,0)` ray carries one class. At `(b,0)`, the near and far open class intervals meet at the unique separating cutoff, with radius squared `16/25` and `37/64` at the two widths. The second cutoff is irrational. The manuscript proves support-wide coverage with a countable library and a positive error floor for each fixed finite feedback alphabet.

## Archived neural counts

The input CSV is a byte-for-byte copy of `Supporting_Research_Data/results/frozen_one_bit_test_counts.csv` in `HalfMoon_INS_Supporting_Research_Data.zip`. The audit script can compare the copies directly when that archive is available.

```sh
python audit_frozen_counts.py --original-archive /path/to/HalfMoon_INS_Supporting_Research_Data.zip
```

The audit recomputes the totals, paired-seed means and two simultaneous 95% Bonferroni-adjusted paired t intervals from the archived counts. The analysis unit is a seed. The 500,000 observations are shared across representations, and the direction-only and one-bit counts are 54,362 and 3. The three one-bit errors occurred in seed 2003. The supplementary manuscript documents the model fitting and validation procedure and identifies the original research release.

## Figure 4

`Figure4/reproduce_figure4.py` renders `threshold_phase.pdf` and `threshold_phase.png`. It calculates the analytical common-threshold bounds and plots the population-risk samples in `Figure4/risk_curves.csv`. This input is a byte-for-byte copy of `Supporting_Research_Data/results/risk_curves.csv` from the same V18 research archive. The line patterns distinguish the risk curves in grayscale.

## Result files

| File in `outputs/` | Contents |
| --- | --- |
| `feedback_grid.csv` | 80 rows for the geometry, radial budget and resolution combinations |
| `contact_grid.csv` | One-bit comparator results at first contact at the two specified widths |
| `contact_rays_exact.csv` | Exact arithmetic checks of the four exceptional ray orientations at each width |
| `frozen_counts_audit.csv` | Recomputed counts, paired-seed summary statistics and simultaneous intervals |
