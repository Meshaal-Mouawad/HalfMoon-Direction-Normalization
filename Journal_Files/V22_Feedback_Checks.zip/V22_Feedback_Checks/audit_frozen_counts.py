"""Recompute the reported held-out summaries from the ten archived seeds."""

import argparse
import csv
from pathlib import Path
from statistics import mean, stdev
from zipfile import ZipFile

from scipy.stats import t

from feedback_validation import write_csv


FROZEN_MEMBER = "Supporting_Research_Data/results/frozen_one_bit_test_counts.csv"
INPUT = Path(__file__).resolve().parent / "inputs" / "frozen_one_bit_test_counts.csv"
COLUMNS = (
    "raw_errors", "direction_errors", "direction_bit_errors",
    "direction_radius_errors", "explicit_decoder_errors",
)


def summarize(source):
    seeds = [{key: int(value) for key, value in row.items()} for row in csv.DictReader(source.splitlines())]
    assert [row["seed"] for row in seeds] == list(range(2001, 2011))
    assert all(row["test_examples"] == 50_000 for row in seeds)
    assert all(0 <= row[key] <= row["test_examples"] for row in seeds for key in COLUMNS)
    total = sum(row["test_examples"] for row in seeds)
    errors = {key: sum(row[key] for row in seeds) for key in COLUMNS}
    assert list(errors.values()) == [0, 54_362, 3, 0, 0]
    assert [row["seed"] for row in seeds if row["direction_bit_errors"]] == [2003]
    values = {key: [100 * row[key] / row["test_examples"] for row in seeds] for key in COLUMNS}
    rows = [{
        "quantity": key, "test_observations": total, "test_error_count": errors[key],
        "mean_percent_or_pp": f"{mean(values[key]):.10f}",
        "seed_sd_percent_or_pp": f"{stdev(values[key]):.10f}",
        "simultaneous_95pct_lower_pp": "", "simultaneous_95pct_upper_pp": "",
    } for key in COLUMNS]

    # Two prespecified contrasts, with two tails each, use the same t critical value.
    critical = t.ppf(1 - 0.05 / 4, df=len(seeds) - 1)
    for comparator in ("direction_errors", "direction_radius_errors"):
        differences = [bit - other for bit, other in zip(values["direction_bit_errors"], values[comparator])]
        center, sd = mean(differences), stdev(differences)
        margin = critical * sd / len(seeds) ** 0.5
        rows.append({
            "quantity": f"direction_bit_errors_minus_{comparator}",
            "test_observations": total, "test_error_count": "",
            "mean_percent_or_pp": f"{center:.10f}", "seed_sd_percent_or_pp": f"{sd:.10f}",
            "simultaneous_95pct_lower_pp": f"{center - margin:.10f}",
            "simultaneous_95pct_upper_pp": f"{center + margin:.10f}",
        })
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("reproduced"))
    parser.add_argument("--original-archive", type=Path)
    args = parser.parse_args()
    source = INPUT.read_bytes()
    if args.original_archive:
        with ZipFile(args.original_archive) as archive:
            assert archive.read(FROZEN_MEMBER) == source
    args.output.mkdir(parents=True, exist_ok=True)
    write_csv(args.output / "frozen_counts_audit.csv", summarize(source.decode("utf-8")))


if __name__ == "__main__":
    main()
