"""Reproduce Figure 4 using frozen V18 risk samples and the analytical bounds."""
from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

CRITICAL = math.sqrt(27 / 85)
TOUCH = math.sqrt(3 / 5)


def threshold_bounds(h):
    d2 = (h / 2) ** 2
    return np.sqrt(0.49 + d2), (0.39 - d2) / np.sqrt(0.09 + d2)



def draw_figure(out, curves):
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9,
                         "pdf.fonttype": 42, "svg.fonttype": "none",
                         "axes.spines.top": False, "axes.spines.right": False,
                         "axes.labelcolor":"#233749", "text.color":"#233749",
                         "axes.edgecolor":"#657788", "xtick.color":"#425768",
                         "ytick.color":"#425768", "lines.solid_capstyle":"round"})
    fig, axs = plt.subplots(1, 2, figsize=(8.1, 3.05), constrained_layout=True)
    ax = axs[0]
    h = np.linspace(1e-5, TOUCH, 1001)
    lo, hi = threshold_bounds(h)
    ax.fill_between(h, lo, hi, where=h < CRITICAL, color="#d5e9e4")
    ax.plot(h, hi, color="#1e7065", label="Upper bound", lw=1.65, linestyle="-")
    ax.plot(h, lo, color="#264966", label="Lower bound", lw=1.65, linestyle="--")
    ax.axvline(CRITICAL, color="#687c87", linestyle=(0,(3,3)), lw=.8)
    ax.plot(CRITICAL, threshold_bounds(CRITICAL)[0], "o", ms=4, color="#273c4f")
    ax.annotate(r"$h_{\star}=0.5636$", (CRITICAL,.51), xytext=(-4,1),
                textcoords="offset points", ha="right", fontsize=8)
    ax.text(.18,.92,"Exact recovery", fontsize=8.7, color="#245b51", ha="center")
    ax.set(xlim=(0,.79), ylim=(.46,1.32), xlabel="Center displacement $h$",
           ylabel="Common radius threshold $t$")
    ax.set_title("A   Exact recovery at the midpoint", loc="left", fontweight="semibold", fontsize=10)
    ax.legend(frameon=False, fontsize=7.5, loc="upper right")
    ax = axs[1]
    patterns = {0.50: "-", 0.65: "--", 0.75: ":"}
    for h, values in curves.items():
        ts, risk = np.array(values).T
        ax.plot(ts, risk*100, label=f"$h={h:.2f}$",
                color={.5:"#21689a",.65:"#237267",.75:"#b95414"}[h],
                lw=1.65, linestyle=patterns[h])
    ax.set(xlim=(.55,.94), ylim=(-.11,None), xlabel="Common radius threshold $t$",
           ylabel="Population Bayes error (%)")
    ax.set_title("B   Error with unrestricted decoding", loc="left", fontweight="semibold", fontsize=10)
    ax.legend(frameon=False, fontsize=7.5)
    for ax in axs:
        ax.set_axisbelow(True)
        ax.grid(axis="y", lw=.45, color="#e0e6eb")
    for ext in ("pdf","png"):
        fig.savefig(out / f"threshold_phase.{ext}", dpi=250)
    plt.close(fig)



def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path("rendered"))
    args = parser.parse_args()
    args.out.mkdir(exist_ok=True, parents=True)
    curves = {}
    with Path(__file__).with_name("risk_curves.csv").open(newline="") as stream:
        for row in csv.DictReader(stream):
            h, cutoff, risk = (float(row[key]) for key in ("h", "t", "bit_risk"))
            curves.setdefault(h, []).append((cutoff, risk))
    draw_figure(args.out, curves)


if __name__ == "__main__":
    main()
