"""Direct support and population-risk checks for half-moon feedback encoders."""

import argparse
import csv
from fractions import Fraction
from math import ceil, pi, sqrt
from pathlib import Path

import numpy as np


D = 0.5
WIDTHS = (0.20, 0.40, 0.60, 0.80)
DISPLACEMENT_FRACTIONS = (0.60, 0.75, 0.90, 0.97)
BENCHMARK_H = (0.50, 0.60, 0.75, 0.77)
RADIAL_ALPHABETS = (2, 4)
GRID_SIZES = (16_384, 65_536)
CONTACT_WIDTHS = (Fraction(2, 5), Fraction(1, 4))


def cutoff_design(w, h):
    """Generate the tested design by the manuscript's recurrence."""
    a, b, k = 2 * D - w, 2 * D + w, h / 2
    t = sqrt((a - D) ** 2 + k * k)
    stop = sqrt((b - D) ** 2 + k * k)
    cutoffs = []
    while t < stop:
        p = (D * sqrt(t * t - k * k) - k * k) / t
        next_cutoff = p + sqrt(p * p + a * a - D * D - k * k)
        assert next_cutoff > t
        cutoffs.append(next_cutoff)
        t = next_cutoff
    return np.asarray(cutoffs)


def support_intervals(w, h, n_angles):
    """Intersect each ray with both original Cartesian support inequalities."""
    theta = (np.arange(n_angles) + 0.5) * (2 * pi / n_angles)
    ux, uy = np.cos(theta), np.sin(theta)
    a, b, k = 2 * D - w, 2 * D + w, h / 2
    lower, upper = [], []
    for center_x, center_y, halfplane_sign in ((0, 0, 1), (2 * D, h, -1)):
        dx, dy = D - center_x, k - center_y
        linear = 2 * (dx * ux + dy * uy)
        origin_distance_sq = dx * dx + dy * dy
        # The origin lies inside both inner circles. Each circle therefore
        # has one positive ray intersection, found by its quadratic root.
        assert origin_distance_sq < a * a
        inner = (np.sqrt(linear**2 + 4 * (a * a - origin_distance_sq)) - linear) / 2
        outer = (np.sqrt(linear**2 + 4 * (b * b - origin_distance_sq)) - linear) / 2
        clip = np.full(n_angles, np.inf)
        halfplane_slope = halfplane_sign * uy
        np.divide(-halfplane_sign * dy, halfplane_slope, out=clip, where=halfplane_slope < 0)
        lower.append(inner)
        upper.append(np.minimum(outer, clip))
    return np.asarray(lower), np.asarray(upper), (pi / 2) * (b * b - a * a)


def menu_risk(lower, upper, cuts):
    """Angular error density before normalizing equal-prior class masses."""
    risk = np.zeros(lower.shape[1])
    boundaries = [0, *cuts, np.inf]
    for lo, hi in zip(boundaries[:-1], boundaries[1:]):
        start = np.maximum(lower, lo)
        end = np.minimum(upper, hi)
        area = np.maximum(end**2 - start**2, 0) / 2
        risk += np.minimum(area[0], area[1])
    return risk


def menu_groups(cutoffs, m):
    return [cutoffs[i : i + m - 1] for i in range(0, len(cutoffs), m - 1)]


def split_rays(lower, upper):
    ambiguous = np.all(upper > lower, axis=0)
    near_end = np.minimum(upper[0], upper[1])
    far_start = np.maximum(lower[0], lower[1])
    assert np.all(near_end[ambiguous] < far_start[ambiguous])
    return ambiguous, near_end, far_start


def menu_hits(cuts, near_end, far_start):
    return np.any((cuts[:, None] >= near_end) & (cuts[:, None] <= far_start), axis=0)


def evaluate_menus(w, h, m, n_angles, cutoffs=None):
    lower, upper, class_area = support_intervals(w, h, n_angles)
    ambiguous, near_end, far_start = split_rays(lower, upper)
    if cutoffs is None:
        cutoffs = cutoff_design(w, h)
    design = menu_groups(cutoffs, m)
    equally_spaced = menu_groups(np.linspace(cutoffs[0], cutoffs[-1], len(cutoffs)), m)
    assert [len(menu) for menu in design] == [len(menu) for menu in equally_spaced]
    chosen = np.full(n_angles, -1, dtype=int)
    for index, cuts in enumerate(design):
        first_hit = ambiguous & (chosen < 0) & menu_hits(cuts, near_end, far_start)
        chosen[first_hit] = index
    assert np.all(chosen[ambiguous] >= 0)
    designed_risks = np.stack([menu_risk(lower, upper, cuts) for cuts in design])
    selected_risk = designed_risks[np.maximum(chosen, 0), np.arange(n_angles)]
    control_risks = np.stack([menu_risk(lower, upper, cuts) for cuts in equally_spaced])
    control_risk = np.min(control_risks, axis=0)
    missed = ambiguous & ~menu_hits(np.concatenate(equally_spaced), near_end, far_start)
    assert np.array_equal(control_risk > 0, missed)
    normalizer = 100 * (2 * pi / n_angles) / (2 * class_area)
    design_error = normalizer * np.sum(selected_risk)
    assert design_error == 0
    return {
        "M_radial_only": len(cutoffs) + 1,
        "K_menus": len(design),
        "ambiguous_rays": int(np.count_nonzero(ambiguous)),
        "designed_uncovered_rays": int(np.count_nonzero(ambiguous & (chosen < 0))),
        "designed_percent_error": design_error,
        "equal_spacing_uncovered_rays": int(np.count_nonzero(missed)),
        "equal_spacing_oracle_percent_error": normalizer * np.sum(control_risk),
        "best_fixed_designed_menu_percent_error": normalizer * np.min(np.sum(designed_risks, axis=1)),
    }


def format_results():
    configurations = [
        ("width_grid", v, fraction * sqrt(1 - v))
        for v in WIDTHS
        for fraction in DISPLACEMENT_FRACTIONS
    ] + [("benchmark", 0.40, h) for h in BENCHMARK_H]
    rows = []
    for case, v, h in configurations:
        w = v * D
        cutoffs = cutoff_design(w, h)
        for m in RADIAL_ALPHABETS:
            for n_angles in GRID_SIZES:
                row = evaluate_menus(w, h, m, n_angles, cutoffs)
                assert row["K_menus"] == ceil((row["M_radial_only"] - 1) / (m - 1))
                rows.append({
                    "case": case, "v": v, "h": f"{h:.12f}",
                    "h_over_hc": f"{h / sqrt(1 - v):.12f}",
                    "m_radial_bins_per_menu": m, "angular_nodes": n_angles, **row,
                })
    return rows


def grid_contact(v, n_angles):
    """Exercise the singleton cutoff and dyadic choices on the contact grid."""
    w = float(v) * D
    h = sqrt(1 - float(v))
    contact_cutoff = sqrt((D + w) ** 2 + (h / 2) ** 2)
    lower, upper, class_area = support_intervals(w, h, n_angles)
    ambiguous, near_end, far_start = split_rays(lower, upper)
    in_gap = ambiguous & (near_end <= contact_cutoff) & (contact_cutoff <= far_start)
    cut = np.full(n_angles, contact_cutoff)
    selected = in_gap.copy()
    level = 0
    while np.any(ambiguous & ~selected):
        missing = ambiguous & ~selected
        stride = 2**level
        candidates = np.ceil(near_end[missing] * stride) / stride
        assert np.all((0 < candidates) & (candidates <= 2))
        admitted = candidates <= far_start[missing]
        valid = np.flatnonzero(missing)[admitted]
        cut[valid] = candidates[admitted]
        selected[valid] = True
        level += 1
        assert level < 40
    risk = 100 * (2 * pi / n_angles) * np.sum(menu_risk(lower, upper, [cut])) / (2 * class_area)
    assert risk == 0
    return {
        "v_exact": str(v), "angular_nodes": n_angles,
        "ambiguous_rays": int(np.count_nonzero(ambiguous)),
        "rays_using_contact_cutoff": int(np.count_nonzero(in_gap)),
        "rays_using_dyadics": int(np.count_nonzero(ambiguous & ~in_gap)),
        "largest_dyadic_denominator_exponent": level - 1,
        "uncovered_rays": int(np.count_nonzero(ambiguous & ~selected)),
        "one_bit_percent_error": risk,
    }


def exceptional_contact_rays(v):
    """Prove the endpoint branches by rational arithmetic in ray parameter s."""
    d = Fraction(1, 2)
    w = d * v
    a, b = 2 * d - w, 2 * d + w
    k_sq = d * (d - w)
    rows = []
    for x, boundary in ((a, "a"), (b, "b")):
        # Ray P(s)=(d+(x-d)s, k(1-s)), with s=1 on y=0.
        # For class 0 and 1, the vertical squared terms are respectively
        # k^2(1-s)^2 and k^2(1+s)^2. The midpoint is inside both inner disks.
        radius_sq = (x - d) ** 2 + k_sq
        assert d * d + k_sq < a * a
        class0_radius_sq_at_one = x * x
        class1_radius_sq_at_one = (x - 2 * d) ** 2 + 4 * k_sq
        class0_derivative_at_one = 2 * x * (x - d)
        class1_derivative_at_one = 2 * (x - 2 * d) * (x - d) + 4 * k_sq
        assert class0_derivative_at_one > 0 and class1_derivative_at_one > 0
        assert class1_radius_sq_at_one == a * a < b * b
        # Class 1 enters at s=1 and its half-plane y<h permits all s>=0.
        # Class 0 must have s<1. At x=a it is empty; at x=b the
        # outer circle and the half-plane both end its open interval at 1.
        assert class0_radius_sq_at_one == (a * a if boundary == "a" else b * b)
        for orientation in ("rightward", "reflected"):
            left_label, right_label = (0, 1) if orientation == "rightward" else (1, 0)
            rows.append({
                "v_exact": str(v), "rightward_diameter_boundary": boundary,
                "orientation": orientation, "s_crossing_exact": 1,
                "radius_squared_at_crossing_exact": str(radius_sq),
                "class_before_crossing": left_label if boundary == "b" else "none",
                "class_after_crossing": right_label,
                "singleton_cutoff_squared_exact": str(radius_sq) if boundary == "b" else "none",
            })
    return rows


def write_csv(path, rows):
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("reproduced"))
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    write_csv(args.output / "feedback_grid.csv", format_results())
    write_csv(args.output / "contact_grid.csv", [grid_contact(v, GRID_SIZES[-1]) for v in CONTACT_WIDTHS])
    exact_rows = [row for v in CONTACT_WIDTHS for row in exceptional_contact_rays(v)]
    write_csv(args.output / "contact_rays_exact.csv", exact_rows)


if __name__ == "__main__":
    main()
